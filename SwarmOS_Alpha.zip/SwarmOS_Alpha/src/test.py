print("hello user Mannu Rani\n")
a=6+8
print(a)