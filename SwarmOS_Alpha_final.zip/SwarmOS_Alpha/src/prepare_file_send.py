# import base64

# # Path to the file you want to send
# with open("test_secret.txt", "rb") as f:
#     b64data = base64.b64encode(f.read()).decode()

# # Print the JSON string to send
# print("Enter this on SwarmOS when it asks for task args:")
# print()
# print(f'{{"filename": "received_test_secret.txt", "data": "{b64data}"}}')

# import base64

# with open("ss.zip", "rb") as f:
#     b64data = base64.b64encode(f.read()).decode()

# print("Paste this into SwarmOS task args:")
# print(f'{{"filename": "received_folder.zip", "data": "{b64data}"}}')


import base64
import json

zip_filename = "ss.zip"
output_json = "task_args.json"
received_filename = "received_folder.zip"

# Read and encode the ZIP file
with open(zip_filename, "rb") as f:
    b64data = base64.b64encode(f.read()).decode()

# Create the JSON payload
payload = {
    "filename": received_filename,
    "data": b64data
}

# Save to JSON file
with open(output_json, "w") as f:
    json.dump(payload, f)

print(f"✅ JSON written to '{output_json}'. Upload this file to SwarmOS.")
