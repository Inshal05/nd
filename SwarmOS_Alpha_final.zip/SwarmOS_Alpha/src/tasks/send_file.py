# tasks/send_file.py

import base64

def run(args):
    try:
        filename = args['filename']
        filedata_b64 = args['data']

        # Decode base64 and write the file
        filedata = base64.b64decode(filedata_b64)
        with open(filename, 'wb') as f:
            f.write(filedata)

        return f"[SUCCESS] File '{filename}' written on remote node."
    except Exception as e:
        return f"[ERROR] {str(e)}"
