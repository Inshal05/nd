def run(args):
    return f"[ECHO] Received: {args}"
