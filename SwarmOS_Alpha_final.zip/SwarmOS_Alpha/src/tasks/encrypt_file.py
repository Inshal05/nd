# tasks/encrypt_file.py

from Crypto.Cipher import AES
import os

def run(args):
    try:
        filepath = args['filepath']
        key = args['key']  # Must be 16, 24, or 32 bytes

        if len(key) not in (16, 24, 32):
            return "[ERROR] Key must be 16, 24, or 32 bytes long."

        with open(filepath, 'rb') as f:
            data = f.read()

        cipher = AES.new(key.encode(), AES.MODE_EAX)
        ciphertext, tag = cipher.encrypt_and_digest(data)

        enc_file = filepath + ".enc"
        with open(enc_file, 'wb') as f:
            f.write(cipher.nonce + tag + ciphertext)

        return f"[SUCCESS] File encrypted and saved as {enc_file}"
    except Exception as e:
        return f"[ERROR] {str(e)}"
