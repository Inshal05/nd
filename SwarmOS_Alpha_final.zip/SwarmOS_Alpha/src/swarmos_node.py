# src/swarmos_node.py
import socket
import threading
import psutil
import json
import os
import importlib.util

# Get user input
HOST = socket.gethostbyname(socket.gethostname())
PORT = int(input(f"Enter port for this peer (default 5000): ") or 5000)
print(f"[INFO] Your local IP is: {HOST}")

PEERS = {}  # {name: (ip, port)}

def handle_client(conn, addr):
    data = conn.recv(4096).decode()
    if data.startswith("TASK:"):
        payload = json.loads(data[5:])
        task = payload['task']
        args = payload['args']
        print(f"[TASK RECEIVED] {task} with args {args}")
        result = run_task(task, args)
        conn.sendall(result.encode())
    conn.close()

def run_task(task, args):
    try:
        path = f"tasks/{task}.py"
        if not os.path.exists(path):
            return f"[ERROR] Task {task} not found."
        spec = importlib.util.spec_from_file_location(task, path)
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        return mod.run(args)
    except Exception as e:
        return f"[TASK ERROR] {str(e)}"

def start_server():
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.bind(("0.0.0.0", PORT))  # Listen on all interfaces
    server.listen()
    print(f"[PEER STARTED] Listening on {HOST}:{PORT} ...")
    while True:
        conn, addr = server.accept()
        threading.Thread(target=handle_client, args=(conn, addr)).start()

def send_task(target_ip, target_port, task, args):
    try:
        s = socket.socket()
        s.connect((target_ip, target_port))
        payload = json.dumps({"task": task, "args": args})
        s.sendall(f"TASK:{payload}".encode())
        data = s.recv(4096).decode()
        s.close()
        print(f"[RESPONSE FROM PEER] {data}")
    except Exception as e:
        print(f"[ERROR] Could not connect to {target_ip}:{target_port} - {e}")

# Run the server in a background thread
threading.Thread(target=start_server, daemon=True).start()

# Menu to test sending a task
while True:
    cmd = input("\n[COMMAND] Type 'send' to send a task or 'exit' to quit: ").strip().lower()
    if cmd == "exit":
        break
    elif cmd == "send":
        ip = input("Enter target peer IP: ").strip()
        port = int(input("Enter target peer port: "))
        task = input("Enter task name (e.g., encrypt_file): ").strip()
        args = input("Enter task args (as JSON string): ").strip()
        try:
            args = json.loads(args)
        except:
            print("[ERROR] Invalid JSON for args")
            continue
        send_task(ip, port, task, args)
