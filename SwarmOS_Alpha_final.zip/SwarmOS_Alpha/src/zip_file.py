import shutil
import os

folder_to_zip = input("Enter folder name to compress: ").strip()

if not os.path.isdir(folder_to_zip):
    print(f"[ERROR] Folder '{folder_to_zip}' does not exist.")
else:
    output_zip = folder_to_zip.rstrip("/\\") + ".zip"
    shutil.make_archive(output_zip.replace(".zip", ""), 'zip', folder_to_zip)
    print(f"[+] Compressed '{folder_to_zip}' into '{output_zip}'")
