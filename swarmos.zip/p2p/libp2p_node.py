import asyncio
from libp2p import new_node
from libp2p.peer.peerinfo import info_from_p2p_addr
from multiaddr import Multiaddr
from config.settings import HOST_PORT
from p2p.protocols import PROTOCOL_ID
import json

async def start_libp2p_node(task_handler):
    host = await new_node()
    await host.get_network().listen(Multiaddr(f"/ip4/0.0.0.0/tcp/{HOST_PORT}"))

    async def handle_stream(stream):
        data = await stream.read()
        result = await task_handler(data.decode())
        await stream.write(result.encode())

    host.set_stream_handler(PROTOCOL_ID, handle_stream)

    print(f"SwarmOS Node running at: {host.get_id().pretty()}")
    print("Multiaddr:", f"/ip4/127.0.0.1/tcp/{HOST_PORT}/p2p/{host.get_id().pretty()}")

    # Example: Uncomment to connect to peer
    # await connect_to_peer(host, "/ip4/192.168.0.101/tcp/8000/p2p/QmPeerId")

    await asyncio.Event().wait()

async def connect_to_peer(host, peer_multiaddr_str):
    peer_multiaddr = Multiaddr(peer_multiaddr_str)
    peer_info = info_from_p2p_addr(peer_multiaddr)
    await host.connect(peer_info)
    print("Connected to peer:", peer_info.peer_id)
    return host
