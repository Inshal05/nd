PROTOCOL_ID = "/swarmos/1.0.0"

import json

def encode_task(task: dict) -> bytes:
    return json.dumps(task).encode()

def decode_task(data: bytes) -> dict:
    return json.loads(data.decode())
