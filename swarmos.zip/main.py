from core.node import SwarmNode

if __name__ == "__main__":
    node = SwarmNode()
    node.start()
