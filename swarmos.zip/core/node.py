from p2p.libp2p_node import start_libp2p_node
from core.task_handler import handle_task
import asyncio

class SwarmNode:
    def start(self):
        asyncio.run(start_libp2p_node(handle_task))
