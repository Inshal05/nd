import base64
import zipfile
import os
from config.settings import SHARED_DIR

def store_file(filename, encoded_data):
    os.makedirs(SHARED_DIR, exist_ok=True)
    with open(f"{SHARED_DIR}/{filename}", "wb") as f:
        f.write(base64.b64decode(encoded_data))
    return {"status": "stored"}

def get_file(filename):
    with open(f"{SHARED_DIR}/{filename}", "rb") as f:
        return {"data": base64.b64encode(f.read()).decode()}

def unzip_file(filename):
    path = f"{SHARED_DIR}/{filename}"
    with zipfile.ZipFile(path, 'r') as zip_ref:
        zip_ref.extractall(SHARED_DIR)
    return {"status": "unzipped"}
