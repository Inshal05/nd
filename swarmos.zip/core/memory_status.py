import psutil

def check_memory():
    mem = psutil.virtual_memory()
    return {
        "total": mem.total,
        "available": mem.available,
        "used_percent": mem.percent
    }
