import json
from core.file_utils import store_file, get_file, unzip_file
from core.memory_status import check_memory

async def handle_task(task_json):
    task = json.loads(task_json)
    command = task.get("command")

    if command == "add":
        result = sum(task["args"])
    elif command == "store":
        result = store_file(task["filename"], task["data"])
    elif command == "get":
        result = get_file(task["filename"])
    elif command == "unzip_file":
        result = unzip_file(task["filename"])
    elif command == "status":
        result = check_memory()
    else:
        result = {"error": "Unknown command"}
    return json.dumps(result)
